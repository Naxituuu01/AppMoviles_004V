package cl.logistica

import kotlin.system.measureTimeMillis

//Mostrar estado con función
fun mostrarEstado(estado: EstadoPedido){
    //when () los estados de la seled class
    when (estado) {
        EstadoPedido.Cargando ->
            println("Estado: Procesando el pedido...")

        is EstadoPedido.Exito ->
            println("Estado: ${estado.mensaje}")

        is EstadoPedido.Error ->
            println("Estado: ${estado.motivo}")
    }

}

fun main() = runBlocking {
    println("Bienvenido casa valdés")

    val pedido = Pedido(
        id = "PED-2873647264",
        producto = "Pollo con papitas fritas",
        cantidad = 2,
        emailCliente = "emailcliente@gmail.com"
    ).apply {
        envioExpress= true
    }

    println("cl.logistica.Pedido creado con apply: $pedido")

    pedido.emailCliente?.let { email ->
        println("Confirmación de pedido enviada a: $email")

        mostrarEstado(EstadoPedido.Cargando)

        val tiempo = measureTimeMillis{
            val estadoFinal = ProcesadorPedido.procesar(pedido)
            mostrarEstado(estadoFinal)
        }
        println("Tiempo toal: $tiempo en milisegundos")
    }

}