package cl.logistica

sealed class EstadoPedido {

    object Cargando: EstadoPedido()

    //Exito
    data class Exito(val mensaje: String) : EstadoPedido()

    //Error
    data class Error(val motivo: String) : EstadoPedido()
}