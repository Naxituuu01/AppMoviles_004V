package cl.logistica

object ProcesadorPedido {

    //1 funcion suspendida
    private suspend fun consultarStock(pedido: Pedido) : Boolean{
        println("Consultando inventario...")
        delay(10000)
        return pedido.cantidad <= 5
    }
    //Simular el proceso de pago
    private suspend fun autorizarPago(): Boolean{
        println("Autorizando pago, consultando al banco...")
        delay(15000)
        return true
    }

    //Corrutina Scope
    suspend fun procesar(pedido: Pedido): EstadoPedido = corroutineScope{
        //async
        val stockPendiente = async {
            consultarStock(pedido)
        }

        val pagoPendiente = async {
            autorizarPago()
        }

        val hayStock = stockPendiente.await()
        val pagoAprobado = pagoPendiente.await()
        when {
            !hayStock ->
                EstadoPedido.Error("No existe stock suficiente.")

            !pagoAprobado ->
                EstadoPedido.Error("El pago fue rechazado.")

            else ->
                EstadoPedido.Exito("cl.logistica.Pedido ${pedido.id} aprobado.")
        }
    }
}